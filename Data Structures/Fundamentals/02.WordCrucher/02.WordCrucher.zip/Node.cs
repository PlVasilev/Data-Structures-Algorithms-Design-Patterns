﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.WordCruncher
{
    public class Node
    {
        public string Key { get; set; }

        public List<Node> Value { get; set; }
    }
}
