﻿using System.Collections.Generic;

namespace _02.MaxHeap
{
    using System;

    public class MaxHeap<T> : IAbstractHeap<T>
        where T : IComparable<T>
    {
        private List<T> _elements;

        public MaxHeap()
        {
            this._elements = new List<T>();
        }

        public int Size => this._elements.Count;

        public void Add(T element)
        {
            this._elements.Add(element);
            this.HeapifyUp();
        }

        private void HeapifyUp()
        {
            int currentIndex = this.Size - 1;
            int parentIndex = this.GetParentIndex(currentIndex);
            while (this.ValidateIndex(currentIndex) && this.IsGreater(currentIndex, parentIndex))
            {
                var temp = this._elements[currentIndex];
                this._elements[currentIndex] = this._elements[parentIndex];
                this._elements[parentIndex] = temp;

                currentIndex = parentIndex;
                parentIndex = this.GetParentIndex(currentIndex);
            }
        }

        private bool IsGreater(int currentIndex, int parentIndex)
            => this._elements[currentIndex].CompareTo(this._elements[parentIndex]) > 0;
        
        private int GetParentIndex(int childIndex) => (childIndex - 1) / 2;
        
        private bool ValidateIndex(int index) =>  index > 0;
        

        private void EnsureNotEmpty()
        {
            if (this.Size == 0) throw new InvalidOperationException();
        }

        public T Peek()
        {
            this.EnsureNotEmpty();
            return this._elements[0];
        }
    }
}
