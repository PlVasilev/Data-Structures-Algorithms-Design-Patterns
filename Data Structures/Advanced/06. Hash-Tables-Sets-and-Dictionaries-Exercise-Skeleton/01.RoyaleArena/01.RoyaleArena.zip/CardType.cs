namespace _01.RoyaleArena
{
    public enum CardType {
        MELEE,
        RANGED,
        SPELL,
        BUILDING
    }
}