﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Wintellect.PowerCollections;

/// <summary>
/// The ThreadExecutor is the concrete implementation of the IScheduler.
/// You can send any class to the judge system as long as it implements
/// the IScheduler interface. The Tests do not contain any <e>Reflection</e>!
/// </summary>
public class ThreadExecutor : IScheduler
{
    private List<Task> _listTask = new List<Task>();
    private Dictionary<int, Task> _dictTask = new Dictionary<int, Task>();
    private Dictionary<Priority, HashSet<Task>> _priorityDict = 
        new Dictionary<Priority, HashSet<Task>>();

    public IEnumerator<Task> GetEnumerator()
    {
        return _listTask.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public int Count => _dictTask.Count;

    public void Execute(Task task)
    {
        if (Contains(task))
        {
            throw new ArgumentException();
        }
        _listTask.Add(task);
        _dictTask[task.Id]= task;

        if (!_priorityDict.ContainsKey(task.TaskPriority))
        {
            _priorityDict[task.TaskPriority] = new HashSet<Task>();
        }
        _priorityDict[task.TaskPriority].Add(task);
    }

    public bool Contains(Task task)
    {
        return _dictTask.ContainsKey(task.Id);
    }

    public Task GetById(int id)
    {
        if (!_dictTask.ContainsKey(id))
        {
            throw new ArgumentException();
        }

        return _dictTask[id];
    }

    public Task GetByIndex(int index)
    {
        if (index < 0 || index >= Count)
        {
            throw new ArgumentOutOfRangeException();
        }

        return _listTask[index];
    }

    public int Cycle(int cycles)
    {
        if (_listTask.Count == 0)
        {
            throw new InvalidOperationException();
        }
        var result = 0;

        for (int i = 0; i < _listTask.Count; i++)
        {
            _listTask[i].Consumption -= cycles;
            if (_listTask[i].Consumption <= 0)
            {
                _dictTask.Remove(_listTask[i].Id);
                _priorityDict[_listTask[i].TaskPriority].Remove(_listTask[i]);
                if (_priorityDict[_listTask[i].TaskPriority].Count == 0)
                {
                    _priorityDict.Remove(_listTask[i].TaskPriority);
                }
                _listTask.Remove(_listTask[i]);
                result++;
                i--;
            }
         
        }
        
        return result;
    } 

    public void ChangePriority(int id, Priority newPriority)
    {
        var current = GetById(id);
        _priorityDict[current.TaskPriority].Remove(current);
        current.TaskPriority = newPriority;
        if (!_priorityDict.ContainsKey(newPriority))
        {
            _priorityDict[newPriority] = new HashSet<Task>();
        }
        _priorityDict[newPriority].Add(current);
    }

    public IEnumerable<Task> GetByConsumptionRange(int lo, int hi, bool inclusive)
    {
        if (inclusive)
        {
            return _listTask.Where(x => x.Consumption >= lo && x.Consumption <= hi).OrderBy(x => x.Consumption).ThenByDescending(x => x.TaskPriority);
        }
        return _listTask.Where(x => x.Consumption > lo && x.Consumption < hi).OrderBy(x => x.Consumption).ThenByDescending(x => x.TaskPriority);
    }

    public IEnumerable<Task> GetByPriority(Priority type)
    {
        if (!_priorityDict.ContainsKey(type))
        {
            return Enumerable.Empty<Task>();
        }

        return _priorityDict[type].OrderByDescending(x => x.Id);
    }

    public IEnumerable<Task> GetByPriorityAndMinimumConsumption(Priority priority, int lo)
    {
        if (!_priorityDict.ContainsKey(priority))
        {
            return Enumerable.Empty<Task>();
        }

        return _priorityDict[priority].Where(x => x.Consumption >= lo).OrderByDescending(x => x.Id) ;
    }
}
